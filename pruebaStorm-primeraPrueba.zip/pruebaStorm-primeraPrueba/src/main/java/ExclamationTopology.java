import backtype.storm.testing.TestWordSpout;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.Config;
import backtype.storm.StormSubmitter;
import backtype.storm.LocalCluster;
import backtype.storm.utils.Utils;

/**
 * Created by antonio on 27/03/16.
 */

public class ExclamationTopology {



    public static void main(String[] args) throws Exception {
        /**************************************************************************************
         *
         * poner la descripción de la topología
         * Que bolts y spout y desde donde vienen unos y a donde van a parar los otros...
         *
         * ***********************************************************************************/

        /**************************************************************************************
         *
         * Poner la configuración
         *
         **************************************************************************************/

        /**************************************************************************************
         *
         * Poner la descripción del clúster (como se lanzará en modo local
         *
         **************************************************************************************/
    }
}
